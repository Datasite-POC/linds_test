import DiligenceDashboardHaloDesignSprint from '../imports/DiligenceDashboardHaloDesignSprint';

export default function App() {
  return (
    <div className="size-full">
      <DiligenceDashboardHaloDesignSprint />
    </div>
  );
}
