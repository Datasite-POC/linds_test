import svgPaths from "./svg-lb2ri4ncwx";

function LeftNavTabItem() {
  return (
    <div className="content-stretch flex h-[48px] items-center justify-center relative shrink-0 w-[80px]" data-name="<LeftNavTabItem>">
      <div className="h-[18px] relative shrink-0 w-[22px]" data-name="grid icon solid">
        <div className="absolute inset-[6.25%_15%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.4 15.75">
            <path d={svgPaths.p431cdf2} fill="var(--fill-0, #1F2227)" fillOpacity="0.8" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Underline() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Underline">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 31 0">
        <g id="Underline" />
      </svg>
    </div>
  );
}

function Header() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Header">
      <div className="h-[16px] overflow-clip relative shrink-0 w-[91px]" data-name="LOGOMARK">
        <div className="absolute inset-[6%_86.73%_6.73%_1.09%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.0899 13.9636">
            <path d={svgPaths.p3a75f900} fill="var(--fill-0, #575559)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[28.6%_0.27%_5.43%_88.32%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.381 10.5558">
            <path d={svgPaths.p37fa9a00} fill="var(--fill-0, #575559)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[10.67%_12.78%_6.73%_79.93%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.62901 13.2156">
            <path d={svgPaths.p326d1980} fill="var(--fill-0, #575559)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[6%_21.53%_6.73%_75.53%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2.67112 13.9636">
            <path d={svgPaths.p29a90b30} fill="var(--fill-0, #575559)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[28.6%_25.93%_5.43%_64.13%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.04697 10.5558">
            <path d={svgPaths.p1a424d70} fill="var(--fill-0, #575559)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[28.6%_37.34%_5.43%_52.44%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.29713 10.5558">
            <path d={svgPaths.p254a1f00} fill="var(--fill-0, #575559)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[10.67%_49.02%_6.73%_43.65%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.67053 13.2156">
            <path d={svgPaths.pe9cbf80} fill="var(--fill-0, #575559)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[28.6%_57.41%_5.43%_32.38%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.29713 10.5558">
            <path d={svgPaths.p1d603a80} fill="var(--fill-0, #575559)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[6%_68.72%_6.73%_18.08%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.007 13.9636">
            <path d={svgPaths.p30f09e00} fill="var(--fill-0, #575559)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0" data-name="Breadcrumb v2">
        <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Link v2>">
          <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>">
            <p className="font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] relative shrink-0 text-[12px] text-[rgba(31,34,39,0.87)] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
              Home
            </p>
          </div>
          <Underline />
        </div>
      </div>
    </div>
  );
}

function Left() {
  return (
    <div className="content-stretch flex h-full items-center relative shrink-0" data-name="Left">
      <LeftNavTabItem />
      <Header />
    </div>
  );
}

function MaskedIcon() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="comment-dots icon light">
        <div className="absolute inset-[0_10%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
            <path d={svgPaths.p15088680} fill="var(--fill-0, #485EF0)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <MaskedIcon />
      <p className="font-['Roboto:Medium',sans-serif] font-medium leading-[24px] relative shrink-0 text-[#485ef0] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Chat
      </p>
    </div>
  );
}

function MaskedIcon1() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="circle-question icon light">
        <div className="absolute inset-[0_10%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
            <path d={svgPaths.p3c9d5300} fill="var(--fill-0, #485EF0)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon2() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #485EF0)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base1() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <MaskedIcon1 />
      <p className="font-['Roboto:Medium',sans-serif] font-medium leading-[24px] relative shrink-0 text-[#485ef0] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Help
      </p>
      <MaskedIcon2 />
    </div>
  );
}

function MaskedIcon3() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="circle-user icon light light">
        <div className="absolute inset-[0_10%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
            <path d={svgPaths.p38559b00} fill="var(--fill-0, #485EF0)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon4() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #485EF0)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base2() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <MaskedIcon3 />
      <p className="font-['Roboto:Medium',sans-serif] font-medium leading-[24px] relative shrink-0 text-[#485ef0] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        User Name
      </p>
      <MaskedIcon4 />
    </div>
  );
}

function Slide() {
  return (
    <div className="absolute content-stretch flex items-center left-0 opacity-38 p-[7px] top-0" data-name="Slide">
      <div className="bg-[#1f2227] h-[10px] rounded-[100px] shrink-0 w-[26px]" data-name="Slide" />
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <rect fill="var(--fill-0, white)" height="15.75" rx="7.875" width="15.75" x="0.125" y="0.125" />
          <rect height="15.75" rx="7.875" stroke="var(--stroke-0, #747880)" strokeWidth="0.25" width="15.75" x="0.125" y="0.125" />
          <g clipPath="url(#clip0_1_9258)" id="sun-bright">
            <path d={svgPaths.p17a1ee80} fill="var(--fill-0, #747880)" id="Primary" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_9258">
            <rect fill="white" height="14" transform="translate(1 1)" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Knob() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 p-[4px] top-0" data-name="Knob">
      <Icon />
    </div>
  );
}

function Switch() {
  return (
    <div className="h-[24px] relative shrink-0 w-[40px]" data-name="Switch">
      <Slide />
      <Knob />
    </div>
  );
}

function Right() {
  return (
    <div className="content-stretch flex gap-[8px] h-full items-center justify-end px-[16px] relative shrink-0" data-name="Right">
      <div className="content-stretch flex flex-col h-[36px] items-center justify-center overflow-clip px-[8px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
        <Base />
      </div>
      <div className="content-stretch flex flex-col h-[36px] items-center justify-center overflow-clip px-[8px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
        <Base1 />
      </div>
      <div className="content-stretch flex flex-col h-[36px] items-center justify-center overflow-clip px-[8px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
        <Base2 />
      </div>
      <div className="content-stretch flex items-center relative shrink-0" data-name="<SwitchDarkMode>">
        <Switch />
      </div>
    </div>
  );
}

export default function TopNavBar() {
  return (
    <div className="bg-[#f7f8fa] content-stretch flex items-center justify-between relative size-full" data-name="<Top Nav Bar>">
      <div aria-hidden="true" className="absolute border-[rgba(31,34,39,0.12)] border-b border-solid inset-0 pointer-events-none" />
      <Left />
      <Right />
    </div>
  );
}