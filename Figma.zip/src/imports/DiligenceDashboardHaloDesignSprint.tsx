import svgPaths from "./svg-rh87o6fu7z";

function LeftNavTabItem() {
  return (
    <div className="content-stretch flex h-[48px] items-center justify-center relative shrink-0 w-[80px]" data-name="<LeftNavTabItem>">
      <div className="h-[18px] relative shrink-0 w-[22px]" data-name="grid icon solid">
        <div className="absolute inset-[6.25%_15%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.4 15.75">
            <path d={svgPaths.p431cdf2} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Underline() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Underline">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 0">
        <g id="Underline" />
      </svg>
    </div>
  );
}

function Header() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 m-[0px]" data-name="Header">
      <div className="h-[16px] overflow-clip relative shrink-0 w-[91px]" data-name="LOGOMARK">
        <div className="absolute inset-[6%_86.73%_6.73%_1.09%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.0899 13.9636">
            <path d={svgPaths.p3a75f900} fill="var(--fill-0, #0D0D0D)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[28.6%_0.27%_5.43%_88.32%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.381 10.5558">
            <path d={svgPaths.p37fa9a00} fill="var(--fill-0, #0D0D0D)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[10.67%_12.78%_6.73%_79.93%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.62901 13.2156">
            <path d={svgPaths.p326d1980} fill="var(--fill-0, #0D0D0D)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[6%_21.53%_6.73%_75.53%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2.67112 13.9636">
            <path d={svgPaths.p29a90b30} fill="var(--fill-0, #0D0D0D)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[28.6%_25.93%_5.43%_64.13%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.04697 10.5558">
            <path d={svgPaths.p1a424d70} fill="var(--fill-0, #0D0D0D)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[28.6%_37.34%_5.43%_52.44%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.29713 10.5558">
            <path d={svgPaths.p254a1f00} fill="var(--fill-0, #0D0D0D)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[10.67%_49.02%_6.73%_43.65%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.67053 13.2156">
            <path d={svgPaths.pe9cbf80} fill="var(--fill-0, #0D0D0D)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[28.6%_57.41%_5.43%_32.38%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.29713 10.5558">
            <path d={svgPaths.p1d603a80} fill="var(--fill-0, #0D0D0D)" id="Vector" />
          </svg>
        </div>
        <div className="absolute inset-[6%_68.72%_6.73%_18.08%]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.007 13.9636">
            <path d={svgPaths.p30f09e00} fill="var(--fill-0, #0D0D0D)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0" data-name="Breadcrumb v2">
        <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Link v2>">
          <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>">
            <p className="font-['TT_Hoves_Pro_VF_Trial:Regular',sans-serif] font-normal leading-[1.66] not-italic relative shrink-0 text-[#323232] text-[12px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
              Home
            </p>
          </div>
          <Underline />
        </div>
      </div>
    </div>
  );
}

function Left() {
  return (
    <div className="content-stretch flex h-full items-center relative shrink-0" data-name="Left">
      <LeftNavTabItem />
      <Header />
    </div>
  );
}

function MaskedIcon() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="comment-dots icon light">
        <div className="absolute inset-[0_10%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
            <path d={svgPaths.p15088680} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <MaskedIcon />
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Chat
      </p>
    </div>
  );
}

function MaskedIcon1() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="circle-question icon light">
        <div className="absolute inset-[0_10%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
            <path d={svgPaths.p3c9d5300} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon2() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base1() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <MaskedIcon1 />
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Help
      </p>
      <MaskedIcon2 />
    </div>
  );
}

function MaskedIcon3() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="circle-user icon light light">
        <div className="absolute inset-[0_10%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
            <path d={svgPaths.p38559b00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon4() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base2() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <MaskedIcon3 />
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        User Name
      </p>
      <MaskedIcon4 />
    </div>
  );
}

function Slide() {
  return (
    <div className="absolute content-stretch flex items-center left-0 opacity-38 p-[7px] top-0" data-name="Slide">
      <div className="bg-[#191919] h-[10px] rounded-[100px] shrink-0 w-[26px]" data-name="Slide" />
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <rect fill="var(--fill-0, white)" height="15.75" rx="7.875" width="15.75" x="0.125" y="0.125" />
          <rect height="15.75" rx="7.875" stroke="var(--stroke-0, #A3A2A0)" strokeWidth="0.25" width="15.75" x="0.125" y="0.125" />
          <g clipPath="url(#clip0_1_9318)" id="sun-bright">
            <path d={svgPaths.p17a1ee80} fill="var(--fill-0, #A3A2A0)" id="Primary" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_9318">
            <rect fill="white" height="14" transform="translate(1 1)" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Knob() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 p-[4px] top-0" data-name="Knob">
      <Icon />
    </div>
  );
}

function Switch() {
  return (
    <div className="h-[24px] relative shrink-0 w-[40px]" data-name="Switch">
      <Slide />
      <Knob />
    </div>
  );
}

function Right() {
  return (
    <div className="content-stretch flex gap-[8px] h-full items-center justify-end px-[16px] relative shrink-0" data-name="Right">
      <div className="content-stretch flex flex-col h-[36px] items-center justify-center overflow-clip px-[8px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
        <Base />
      </div>
      <div className="content-stretch flex flex-col h-[36px] items-center justify-center overflow-clip px-[8px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
        <Base1 />
      </div>
      <div className="content-stretch flex flex-col h-[36px] items-center justify-center overflow-clip px-[8px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
        <Base2 />
      </div>
      <div className="content-stretch flex items-center relative shrink-0" data-name="<SwitchDarkMode>">
        <Switch />
      </div>
    </div>
  );
}

function TopNavBar() {
  return (
    <div className="bg-[#fafaf7] content-stretch flex h-[48px] items-center justify-between relative shrink-0 w-full" data-name="<Top Nav Bar>">
      <div aria-hidden="true" className="absolute border-[rgba(25,25,25,0.12)] border-b border-solid inset-0 pointer-events-none z-0" />
      <div onClick={(e) => e.stopPropagation()}>
        <Left />
      </div>
      <Right />
    </div>
  );
}

function IconContainer() {
  return (
    <div className="bg-[#dbdad7] content-stretch flex flex-col items-center justify-center relative rounded-[8px] shrink-0 size-[32px]" data-name="Icon Container">
      <div className="h-[18px] relative shrink-0 w-[22px]" data-name="chart-line-up icon solid">
        <div className="absolute inset-[6.25%_10%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.6 15.75">
            <path d={svgPaths.p1fd59180} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function IconContainer1() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative rounded-[8px] shrink-0 size-[32px]" data-name="Icon Container">
      <div className="h-[18px] relative shrink-0 w-[22px]" data-name="file-lines icon light">
        <div className="absolute inset-[0_20%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.2 18">
            <path d={svgPaths.p30018e00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function IconContainer2() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative rounded-[8px] shrink-0 size-[32px]" data-name="Icon Container">
      <div className="h-[18px] relative shrink-0 w-[22px]" data-name="magnifying-glass icon light">
        <div className="absolute inset-[0_10.01%_0.01%_10%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.5983 17.9982">
            <path d={svgPaths.p243ef3a0} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function IconContainer3() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative rounded-[8px] shrink-0 size-[32px]" data-name="Icon Container">
      <div className="h-[18px] relative shrink-0 w-[22px]" data-name="list-check icon light">
        <div className="absolute inset-[6.25%_10%_14.06%_10.01%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.5983 14.3433">
            <path d={svgPaths.pa1c7f80} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function IconContainer4() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative rounded-[8px] shrink-0 size-[32px]" data-name="Icon Container">
      <div className="h-[18px] relative shrink-0 w-[22px]" data-name="comments icon light">
        <div className="absolute inset-[-6.25%_4.97%_-6.25%_5%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.8069 20.25">
            <path d={svgPaths.p32d39680} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function IconContainer5() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative rounded-[8px] shrink-0 size-[32px]" data-name="Icon Container">
      <div className="h-[18px] relative shrink-0 w-[22px]" data-name="users icon light">
        <div className="absolute inset-[3.13%_0_6.25%_0]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 16.3125">
            <path d={svgPaths.p730d780} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function IconContainer6() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative rounded-[8px] shrink-0 size-[32px]" data-name="Icon Container">
      <div className="h-[18px] relative shrink-0 w-[22px]" data-name="user-lock icon light">
        <div className="absolute inset-[0_5%_-6.25%_5%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.8 19.125">
            <path d={svgPaths.p232f0f00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function IconContainer7() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative rounded-[8px] shrink-0 size-[32px]" data-name="Icon Container">
      <div className="h-[18px] relative shrink-0 w-[22px]" data-name="highicon lighter light">
        <div className="absolute inset-[0_7.5%_0_5%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.25 18">
            <path d={svgPaths.p320fa500} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function IconContainer8() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative rounded-[8px] shrink-0 size-[32px]" data-name="Icon Container">
      <div className="h-[18px] relative shrink-0 w-[22px]" data-name="cabinet-filing icon light">
        <div className="absolute inset-[0_20%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.2 18">
            <path d={svgPaths.p51e1700} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function IconContainer9() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative rounded-[8px] shrink-0 size-[32px]" data-name="Icon Container">
      <div className="h-[18px] relative shrink-0 w-[22px]" data-name="chart-pie icon light">
        <div className="absolute inset-[0.36%_5.66%_0_10.06%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.5418 17.9346">
            <path d={svgPaths.p21d0d180} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function IconContainer10() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative rounded-[8px] shrink-0 size-[32px]" data-name="Icon Container">
      <div className="h-[18px] relative shrink-0 w-[22px]" data-name="gear icon light">
        <div className="absolute inset-[-3.13%_9.51%_-3.13%_9.6%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.7957 19.125">
            <path d={svgPaths.p3412a000} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Typography() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center min-h-[24px] px-[6px] relative shrink-0" data-name="Typography">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Regular',sans-serif] font-normal leading-[18px] not-italic relative shrink-0 text-[12px] text-white tracking-[0.16px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Active
      </p>
    </div>
  );
}

function Left1() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Left">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>">
        <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[1.6] not-italic relative shrink-0 text-[#323232] text-[20px] tracking-[0.15px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Project Sonoma
        </p>
      </div>
      <div className="bg-[#b34814] content-stretch flex items-center max-h-[24px] min-h-[24px] overflow-clip px-[4px] py-[3px] relative rounded-[100px] shrink-0" data-name="<Chip - Updated>/<Chip>/Small/Filled/Warning/Enabled">
        <Typography />
      </div>
    </div>
  );
}

function MaskedIcon5() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="icon lightbulb light">
        <div className="absolute inset-[0_20%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
            <path d={svgPaths.p2c5f580} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base3() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <MaskedIcon5 />
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>{`Suggest & vote`}</p>
    </div>
  );
}

function MaskedIcon6() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="compass icon light">
        <div className="absolute inset-[0_10%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
            <path d={svgPaths.p10a91d80} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base4() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <MaskedIcon6 />
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Show me around
      </p>
    </div>
  );
}

function MaskedIcon7() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="arrow-rotate-left icon light">
        <div className="absolute inset-[0_10%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
            <path d={svgPaths.p27b9f600} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base5() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <MaskedIcon7 />
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Reset filters
      </p>
    </div>
  );
}

function MaskedIcon8() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="sliders icon light">
        <div className="absolute inset-[3.13%_10%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 15">
            <path d={svgPaths.p2f0f9180} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon9() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base6() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <MaskedIcon8 />
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Manage dashboard
      </p>
      <MaskedIcon9 />
    </div>
  );
}

function Right1() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Right">
      <div className="h-[36px] relative rounded-[8px] shrink-0" data-name="<ButtonGroup>">
        <div className="content-stretch flex h-full items-center overflow-clip relative rounded-[inherit]">
          <div className="content-stretch flex flex-col h-[32px] items-center justify-center overflow-clip px-[16px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
            <Base3 />
          </div>
          <div className="flex h-0 items-center justify-center relative self-center shrink-0 w-0" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "19" } as React.CSSProperties}>
            <div className="-rotate-90 flex-none h-full">
              <div className="h-full relative w-[36px]" data-name="Vertical">
                <div className="absolute inset-[-1px_0_0_0]">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36 1">
                    <line id="Vertical" stroke="var(--stroke-0, #191919)" strokeOpacity="0.5" x2="36" y1="0.5" y2="0.5" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
          <div className="content-stretch flex flex-col h-[32px] items-center justify-center overflow-clip px-[16px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
            <Base4 />
          </div>
          <div className="flex h-0 items-center justify-center relative self-center shrink-0 w-0" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "19" } as React.CSSProperties}>
            <div className="-rotate-90 flex-none h-full">
              <div className="h-full relative w-[36px]" data-name="Vertical">
                <div className="absolute inset-[-1px_0_0_0]">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36 1">
                    <line id="Vertical" stroke="var(--stroke-0, #191919)" strokeOpacity="0.5" x2="36" y1="0.5" y2="0.5" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
          <div className="content-stretch flex flex-col h-[32px] items-center justify-center overflow-clip px-[16px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
            <Base5 />
          </div>
          <div className="flex h-0 items-center justify-center relative self-center shrink-0 w-0" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "19" } as React.CSSProperties}>
            <div className="-rotate-90 flex-none h-full">
              <div className="h-full relative w-[36px]" data-name="Vertical">
                <div className="absolute inset-[-1px_0_0_0]">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36 1">
                    <line id="Vertical" stroke="var(--stroke-0, #485EF0)" strokeOpacity="0.5" x2="36" y1="0.5" y2="0.5" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
          <div className="content-stretch flex flex-col h-[36px] items-center justify-center overflow-clip px-[16px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
            <Base6 />
          </div>
        </div>
        <div aria-hidden="true" className="absolute border border-[rgba(25,25,25,0.5)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      </div>
    </div>
  );
}

function PageHeader() {
  return (
    <div className="relative shrink-0 w-full" data-name="Page Header">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between pl-[24px] pr-[16px] py-[16px] relative w-full m-[0px]">
          <Left1 />
          <Right1 />
        </div>
      </div>
    </div>
  );
}

function LeftContent() {
  return (
    <div className="content-stretch flex flex-col items-start pr-[16px] relative shrink-0" data-name="Left Content">
      <div className="content-stretch flex h-[16px] items-center justify-center relative shrink-0 w-[20px]" data-name="Size=Medium (16px)">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[6.25%_10%_12.5%_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 13">
              <path d={svgPaths.p1ded8a00} fill="var(--fill-0, #1F2227)" fillOpacity="0.8" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function ListItemText() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px py-[4px] relative" data-name="ListItem Text">
      <p className="font-['Roboto:Regular',sans-serif] font-normal leading-[1.5] relative shrink-0 text-[#1f2227] text-[16px] tracking-[0.15px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        New
      </p>
    </div>
  );
}

function Container() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center px-[16px] py-[8px] relative w-full">
          <LeftContent />
          <ListItemText />
          <div className="bg-white content-stretch flex items-center justify-center px-[6.5px] relative rounded-[100px] shrink-0" data-name="Variant=Standard, Color=None">
            <div className="flex flex-col font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#323232] text-[12px] tracking-[0.14px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
              <p className="leading-[20px]">24</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LeftContent1() {
  return (
    <div className="content-stretch flex flex-col items-start pr-[16px] relative shrink-0" data-name="Left Content">
      <div className="content-stretch flex h-[16px] items-center justify-center relative shrink-0 w-[20px]" data-name="Size=Medium (16px)">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[6.25%_10%_12.5%_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 13">
              <path d={svgPaths.p1ded8a00} fill="var(--fill-0, #1F2227)" fillOpacity="0.8" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function ListItemText1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px py-[4px] relative" data-name="ListItem Text">
      <p className="font-['Roboto:Regular',sans-serif] font-normal leading-[1.5] relative shrink-0 text-[#1f2227] text-[16px] tracking-[0.15px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        Inbox
      </p>
    </div>
  );
}

function Container1() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center px-[16px] py-[8px] relative w-full">
          <LeftContent1 />
          <ListItemText1 />
          <div className="bg-white content-stretch flex items-center justify-center px-[6.5px] relative rounded-[100px] shrink-0" data-name="Variant=Standard, Color=None">
            <div className="flex flex-col font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#323232] text-[12px] tracking-[0.14px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
              <p className="leading-[20px]">24</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LeftContent2() {
  return (
    <div className="content-stretch flex flex-col items-start pr-[16px] relative shrink-0" data-name="Left Content">
      <div className="content-stretch flex h-[16px] items-center justify-center relative shrink-0 w-[20px]" data-name="Size=Medium (16px)">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[6.25%_10%_12.5%_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 13">
              <path d={svgPaths.p1ded8a00} fill="var(--fill-0, #1F2227)" fillOpacity="0.8" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function ListItemText2() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px py-[4px] relative" data-name="ListItem Text">
      <p className="font-['Roboto:Regular',sans-serif] font-normal leading-[1.5] relative shrink-0 text-[#1f2227] text-[16px] tracking-[0.15px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        Action Required
      </p>
    </div>
  );
}

function Container2() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center px-[16px] py-[8px] relative w-full">
          <LeftContent2 />
          <ListItemText2 />
          <div className="bg-white content-stretch flex items-center justify-center px-[6.5px] relative rounded-[100px] shrink-0" data-name="Variant=Standard, Color=None">
            <div className="flex flex-col font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#b34814] text-[12px] tracking-[0.14px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
              <p className="leading-[20px]">24</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ShortcutForDocs() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Shortcut for Docs">
      <div className="content-stretch flex flex-col gap-[8px] items-start pb-[16px] px-[16px] relative size-full">
        <div className="bg-[#fafaf7] content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px overflow-clip relative rounded-[8px] w-full" data-name="<ListItem>">
          <Container />
        </div>
        <div className="bg-[#fafaf7] content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px overflow-clip relative rounded-[8px] w-full" data-name="<ListItem>">
          <Container1 />
        </div>
        <div className="bg-[#fafaf7] content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px overflow-clip relative rounded-[8px] w-full" data-name="<ListItem>">
          <Container2 />
        </div>
      </div>
    </div>
  );
}

function TitleAndInfoIcon() {
  return (
    <div className="content-stretch flex gap-[8px] h-[32px] items-center relative shrink-0" data-name="title and info icon">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>/Widget Name">
        <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[1.57] not-italic relative shrink-0 text-[#323232] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Document Actions
        </p>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0 size-[16px]" data-name="<Icon Container>">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[0_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p30afdb00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon10() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base7() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        All locations
      </p>
      <MaskedIcon10 />
    </div>
  );
}

function Base8() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="capitalize font-['Roboto:Medium',sans-serif] font-medium leading-[24px] relative shrink-0 text-[#485ef0] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Inbox
      </p>
    </div>
  );
}

function DataPoint() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-center min-h-px min-w-px relative" data-name="Data Point 1">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>">
        <p className="font-['AL_Sigla_Trial:Light',sans-serif] leading-[1.2] not-italic relative shrink-0 text-[#323232] text-[60px] tracking-[-0.5px] whitespace-nowrap">24</p>
      </div>
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="<Button>">
        <Base8 />
      </div>
    </div>
  );
}

function MinWidth() {
  return <div className="h-0 shrink-0 w-px" data-name="min-width" />;
}

function Divider() {
  return (
    <div className="h-full relative shrink-0" data-name="Divider">
      <div className="flex flex-row justify-center size-full">
        <div className="content-stretch flex h-full items-start justify-center pb-[44px] pt-[28px] relative">
          <div className="content-stretch flex flex-col h-[24px] items-start relative shrink-0" data-name="<Divider> | Vertical">
            <MinWidth />
            <div className="flex flex-[1_0_0] items-center justify-center min-h-px min-w-px relative w-0" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "19" } as React.CSSProperties}>
              <div className="flex-none h-full rotate-90">
                <div className="h-full relative w-[220px]" data-name="Divider">
                  <div className="absolute inset-[-1px_0_0_0]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 1">
                      <line id="Divider" stroke="var(--stroke-0, #191919)" strokeOpacity="0.12" x2="24" y1="0.5" y2="0.5" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Base9() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="capitalize font-['Roboto:Medium',sans-serif] font-medium leading-[24px] relative shrink-0 text-[#485ef0] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Action Required
      </p>
    </div>
  );
}

function DataPoint1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-center min-h-px min-w-px relative" data-name="Data Point 2">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>">
        <p className="font-['AL_Sigla_Trial:Light',sans-serif] leading-[1.2] not-italic relative shrink-0 text-[#b34814] text-[60px] tracking-[-0.5px] whitespace-nowrap">11</p>
      </div>
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="<Button>">
        <Base9 />
      </div>
    </div>
  );
}

function Number() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-center justify-center min-h-px min-w-px relative w-full" data-name="Number">
      <div className="relative shrink-0 w-full" data-name="<Chart Numbers>">
        <div className="flex flex-row items-center size-full">
          <div className="content-stretch flex gap-[8px] items-center px-[16px] relative w-full">
            <DataPoint />
            <div className="flex flex-row items-center self-stretch">
              <Divider />
            </div>
            <DataPoint1 />
          </div>
        </div>
      </div>
    </div>
  );
}

function WidgetDocumentActions() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[8px] h-[276px] items-start min-w-[324px] overflow-clip pb-[16px] relative rounded-[8px] shadow-[0px_0px_8px_2px_rgba(219,218,215,0.25)] shrink-0 w-[324px]" data-name="<Widget Document Actions>">
      <div className="content-stretch flex gap-[8px] h-[62px] items-center p-[16px] relative shrink-0" data-name="<Widget Header>">
        <TitleAndInfoIcon />
        <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="<Button>">
          <Base7 />
        </div>
      </div>
      <Number />
    </div>
  );
}

function TitleAndInfoIcon1() {
  return (
    <div className="content-stretch flex gap-[8px] h-[32px] items-center relative shrink-0" data-name="title and info icon">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>/Widget Name">
        <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[1.57] not-italic relative shrink-0 text-[#323232] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Documents Published
        </p>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0 size-[16px]" data-name="<Icon Container>">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[0_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p30afdb00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon11() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base10() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Fileroom a
      </p>
      <MaskedIcon11 />
    </div>
  );
}

function Label() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        (1) Contracts
      </p>
    </div>
  );
}

function Bar() {
  return (
    <div className="bg-[#dbdad7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="absolute bg-[#b34814] bottom-0 left-0 right-3/4 top-0" data-name="Series 1" />
    </div>
  );
}

function ChartBar8() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 01>">
      <Label />
      <Bar />
    </div>
  );
}

function Label1() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        (2) Corporate
      </p>
    </div>
  );
}

function Bar1() {
  return (
    <div className="bg-[#dbdad7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="absolute bg-[#ff8818] bottom-0 left-0 right-1/2 top-0" data-name="Series 1" />
    </div>
  );
}

function ChartBar9() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 02>">
      <Label1 />
      <Bar1 />
    </div>
  );
}

function Label2() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        (3) Environmental
      </p>
    </div>
  );
}

function Bar2() {
  return (
    <div className="bg-[#dbdad7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[59px] relative size-full">
        <div className="bg-[#1e4d36] flex-[1_0_0] min-h-px min-w-px w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function ChartBar10() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 03>">
      <Label2 />
      <Bar2 />
    </div>
  );
}

function Label3() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        (4) Financial
      </p>
    </div>
  );
}

function Bar3() {
  return (
    <div className="bg-[#dbdad7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="absolute bg-[#53856d] bottom-0 left-0 right-1/4 top-0" data-name="Series 1" />
    </div>
  );
}

function ChartBar11() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 04>">
      <Label3 />
      <Bar3 />
    </div>
  );
}

function Label4() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        (5) Human Resources
      </p>
    </div>
  );
}

function Bar4() {
  return (
    <div className="bg-[#dbdad7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[30px] relative size-full">
        <div className="bg-[#651f4a] flex-[1_0_0] min-h-px min-w-px w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function ChartBar12() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 05>">
      <Label4 />
      <Bar4 />
    </div>
  );
}

function Label5() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        (6) Intellectual Property
      </p>
    </div>
  );
}

function Bar5() {
  return (
    <div className="bg-[#dbdad7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[20px] relative size-full">
        <div className="bg-[#9f5481] flex-[1_0_0] min-h-px min-w-px w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function ChartBar13() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 06>">
      <Label5 />
      <Bar5 />
    </div>
  );
}

function Label6() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>{`(7) Research & Development`}</p>
    </div>
  );
}

function Bar6() {
  return (
    <div className="bg-[#dbdad7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[20px] relative size-full">
        <div className="bg-[#6c6e1c] flex-[1_0_0] min-h-px min-w-px w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function ChartBar5() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 06>">
      <Label6 />
      <Bar6 />
    </div>
  );
}

function BarChart() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Bar Chart">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[12px] items-start pl-[32px] pr-[16px] relative size-full">
          <ChartBar8 />
          <ChartBar9 />
          <ChartBar10 />
          <ChartBar11 />
          <ChartBar12 />
          <ChartBar13 />
          <ChartBar5 />
        </div>
      </div>
    </div>
  );
}

function WidgetDocumentsPublished() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[8px] h-[276px] items-start min-w-[324px] overflow-clip pb-[16px] relative rounded-[8px] shadow-[0px_0px_8px_2px_rgba(219,218,215,0.25)] shrink-0 w-[324px]" data-name="<Widget Documents Published>">
      <div className="content-stretch flex gap-[8px] h-[62px] items-center p-[16px] relative shrink-0" data-name="<Widget Header>">
        <TitleAndInfoIcon1 />
        <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="<Button>">
          <Base10 />
        </div>
      </div>
      <BarChart />
    </div>
  );
}

function TitleAndInfoIcon2() {
  return (
    <div className="content-stretch flex gap-[8px] h-[32px] items-center relative shrink-0" data-name="title and info icon">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>/Widget Name">
        <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[1.57] not-italic relative shrink-0 text-[#323232] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Invitation Status
        </p>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0 size-[16px]" data-name="<Icon Container>">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[0_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p30afdb00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon12() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base11() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        All Roles
      </p>
      <MaskedIcon12 />
    </div>
  );
}

function ChartPie() {
  return (
    <div className="relative shrink-0 size-[190px]" data-name="<Chart Pie>">
      <div className="absolute inset-[-0.53%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 192 192">
          <g id="<Chart Pie>">
            <path d={svgPaths.p1f856800} fill="var(--fill-0, #A3A2A0)" id="Ellipse 4" stroke="var(--stroke-0, white)" strokeWidth="2" />
            <path d={svgPaths.p21886f00} fill="var(--fill-0, #C02641)" id="Ellipse 5" stroke="var(--stroke-0, white)" strokeWidth="2" />
            <path d={svgPaths.pa6def00} fill="var(--fill-0, #1D595C)" id="Ellipse 3" stroke="var(--stroke-0, white)" strokeWidth="2" />
            <path d={svgPaths.p1f38b800} fill="var(--fill-0, #6C6E1C)" id="Ellipse 2" stroke="var(--stroke-0, white)" strokeWidth="2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function WidgetContent() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Widget Content">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-stretch flex items-center justify-center px-[8px] relative size-full">
          <ChartPie />
        </div>
      </div>
    </div>
  );
}

function WidgetInvitationStatus() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[8px] h-[276px] items-start min-w-[324px] overflow-clip pb-[16px] relative rounded-[8px] shadow-[0px_0px_8px_2px_rgba(219,218,215,0.25)] shrink-0 w-[324px]" data-name="<Widget Invitation Status>">
      <div className="content-stretch flex gap-[8px] h-[62px] items-center p-[16px] relative shrink-0" data-name="<Widget Header>">
        <TitleAndInfoIcon2 />
        <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="<Button>">
          <Base11 />
        </div>
      </div>
      <WidgetContent />
    </div>
  );
}

function TitleAndInfoIcon3() {
  return (
    <div className="content-stretch flex gap-[8px] h-[32px] items-center relative shrink-0" data-name="title and info icon">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>/Widget Name">
        <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[1.57] not-italic relative shrink-0 text-[#323232] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Empty Folders
        </p>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0 size-[16px]" data-name="<Icon Container>">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[0_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p30afdb00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon13() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base12() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        All locations
      </p>
      <MaskedIcon13 />
    </div>
  );
}

function Base13() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="capitalize font-['Roboto:Medium',sans-serif] font-medium leading-[24px] relative shrink-0 text-[#485ef0] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Empty Folders
      </p>
    </div>
  );
}

function DataPoint2() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-center min-h-px min-w-px relative" data-name="Data Point 1">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>">
        <p className="font-['AL_Sigla_Trial:Light',sans-serif] leading-[1.167] not-italic relative shrink-0 text-[#323232] text-[96px] tracking-[-1.5px] whitespace-nowrap">24</p>
      </div>
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="<Button>">
        <Base13 />
      </div>
    </div>
  );
}

function Number1() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Number">
      <div className="flex flex-col items-center size-full">
        <div className="content-stretch flex flex-col items-center py-[16px] relative size-full">
          <div className="relative shrink-0 w-full" data-name="<Chart Numbers>">
            <div className="flex flex-row items-center size-full">
              <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
                <DataPoint2 />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function WidgetEmptyFolders() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[8px] h-[276px] items-start min-w-[324px] overflow-clip pb-[16px] relative rounded-[8px] shadow-[0px_0px_8px_2px_rgba(219,218,215,0.25)] shrink-0 w-[324px]" data-name="<Widget Empty Folders>">
      <div className="content-stretch flex gap-[8px] h-[62px] items-center p-[16px] relative shrink-0" data-name="<Widget Header>">
        <TitleAndInfoIcon3 />
        <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
          <Base12 />
        </div>
      </div>
      <Number1 />
    </div>
  );
}

function TitleAndInfoIcon4() {
  return (
    <div className="content-stretch flex gap-[8px] h-[32px] items-center relative shrink-0" data-name="title and info icon">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>/Widget Name">
        <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[1.57] not-italic relative shrink-0 text-[#323232] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Document by Folder
        </p>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0 size-[16px]" data-name="<Icon Container>">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[0_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p30afdb00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon14() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base14() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Fileroom A
      </p>
      <MaskedIcon14 />
    </div>
  );
}

function Label7() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        (1) Contracts
      </p>
    </div>
  );
}

function Bar7() {
  return (
    <div className="bg-[#fafaf7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="absolute bg-[#b34814] bottom-0 left-0 right-3/4 top-0" data-name="Series 1" />
    </div>
  );
}

function ChartBar() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 01>">
      <Label7 />
      <Bar7 />
    </div>
  );
}

function Label8() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        (2) Corporate
      </p>
    </div>
  );
}

function Bar8() {
  return (
    <div className="bg-[#fafaf7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="absolute bg-[#ff8818] bottom-0 left-0 right-1/2 top-0" data-name="Series 1" />
    </div>
  );
}

function ChartBar1() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 02>">
      <Label8 />
      <Bar8 />
    </div>
  );
}

function Label9() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        (3) Environmental
      </p>
    </div>
  );
}

function Bar9() {
  return (
    <div className="bg-[#fafaf7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[59px] relative size-full">
        <div className="bg-[#1e4d36] flex-[1_0_0] min-h-px min-w-px w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function ChartBar2() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 03>">
      <Label9 />
      <Bar9 />
    </div>
  );
}

function Label10() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        (4) Financial
      </p>
    </div>
  );
}

function Bar10() {
  return (
    <div className="bg-[#fafaf7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="absolute bg-[#53856d] bottom-0 left-0 right-1/4 top-0" data-name="Series 1" />
    </div>
  );
}

function ChartBar3() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 04>">
      <Label10 />
      <Bar10 />
    </div>
  );
}

function Label11() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        (5) Human Resources
      </p>
    </div>
  );
}

function Bar11() {
  return (
    <div className="bg-[#fafaf7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[30px] relative size-full">
        <div className="bg-[#651f4a] flex-[1_0_0] min-h-px min-w-px w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function ChartBar4() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 05>">
      <Label11 />
      <Bar11 />
    </div>
  );
}

function Label12() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        (6) Intellectual Property
      </p>
    </div>
  );
}

function Bar12() {
  return (
    <div className="bg-[#fafaf7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[20px] relative size-full">
        <div className="bg-[#9f5481] flex-[1_0_0] min-h-px min-w-px w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function ChartBar6() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 06>">
      <Label12 />
      <Bar12 />
    </div>
  );
}

function Label13() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>{`(7) Research & Development`}</p>
    </div>
  );
}

function Bar13() {
  return (
    <div className="bg-[#fafaf7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[20px] relative size-full">
        <div className="bg-[#6c6e1c] flex-[1_0_0] min-h-px min-w-px w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function ChartBar7() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 06>">
      <Label13 />
      <Bar13 />
    </div>
  );
}

function BarChart1() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Bar Chart">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[12px] items-start pl-[32px] pr-[16px] relative size-full">
          <ChartBar />
          <ChartBar1 />
          <ChartBar2 />
          <ChartBar3 />
          <ChartBar4 />
          <ChartBar6 />
          <ChartBar7 />
        </div>
      </div>
    </div>
  );
}

function WidgetDocumentsPublished1() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[8px] h-[276px] items-start min-w-[324px] overflow-clip pb-[16px] relative rounded-[8px] shadow-[0px_0px_8px_2px_rgba(219,218,215,0.25)] shrink-0 w-[324px]" data-name="<Widget Documents Published>">
      <div className="content-stretch flex gap-[8px] h-[62px] items-center p-[16px] relative shrink-0" data-name="<Widget Header>">
        <TitleAndInfoIcon4 />
        <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="<Button>">
          <Base14 />
        </div>
      </div>
      <BarChart1 />
    </div>
  );
}

function TitleAndInfoIcon5() {
  return (
    <div className="content-stretch flex gap-[8px] h-[32px] items-center relative shrink-0" data-name="title and info icon">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>/Widget Name">
        <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[1.57] not-italic relative shrink-0 text-[#323232] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Placeholders
        </p>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0 size-[16px]" data-name="<Icon Container>">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[0_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p30afdb00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon15() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base15() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        All locations
      </p>
      <MaskedIcon15 />
    </div>
  );
}

function Base16() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="capitalize font-['Roboto:Medium',sans-serif] font-medium leading-[24px] relative shrink-0 text-[#485ef0] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        All locations
      </p>
    </div>
  );
}

function DataPoint3() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-center min-h-px min-w-px relative" data-name="Data Point 1">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>">
        <p className="font-['AL_Sigla_Trial:Light',sans-serif] leading-[1.167] not-italic relative shrink-0 text-[#323232] text-[96px] tracking-[-1.5px] whitespace-nowrap">15</p>
      </div>
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="<Button>">
        <Base16 />
      </div>
    </div>
  );
}

function Number2() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Number">
      <div className="flex flex-col items-center size-full">
        <div className="content-stretch flex flex-col items-center py-[16px] relative size-full">
          <div className="relative shrink-0 w-full" data-name="<Chart Numbers>">
            <div className="flex flex-row items-center size-full">
              <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
                <DataPoint3 />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function WidgetPlaceholders() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[8px] h-[276px] items-start min-w-[324px] overflow-clip pb-[16px] relative rounded-[8px] shadow-[0px_0px_8px_2px_rgba(219,218,215,0.25)] shrink-0 w-[324px]" data-name="<Widget Placeholders>">
      <div className="h-[62px] relative shrink-0 w-full" data-name="<Widget Header>">
        <div className="flex flex-row items-center size-full">
          <div className="content-stretch flex gap-[8px] items-center p-[16px] relative size-full">
            <TitleAndInfoIcon5 />
            <div className="flex-[1_0_0] min-h-px min-w-px relative rounded-[8px]" data-name="<Button>">
              <div className="flex flex-col items-end justify-center overflow-clip rounded-[inherit] size-full">
                <div className="content-stretch flex flex-col items-end justify-center px-[8px] py-[6px] relative w-full">
                  <Base15 />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Number2 />
    </div>
  );
}

function TitleAndInfoIcon6() {
  return (
    <div className="content-stretch flex gap-[8px] h-[32px] items-center relative shrink-0" data-name="title and info icon">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>/Widget Name">
        <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[1.57] not-italic relative shrink-0 text-[#323232] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>{`Q&A Progress`}</p>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0 size-[16px]" data-name="<Icon Container>">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[0_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p30afdb00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon16() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base17() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        All locations
      </p>
      <MaskedIcon16 />
    </div>
  );
}

function Base18() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="capitalize font-['Roboto:Medium',sans-serif] font-medium leading-[24px] relative shrink-0 text-[#485ef0] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Outstanding questions
      </p>
    </div>
  );
}

function DataPoint4() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-center min-h-px min-w-px relative" data-name="Data Point 1">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>">
        <p className="font-['AL_Sigla_Trial:Light',sans-serif] leading-[1.167] not-italic relative shrink-0 text-[#323232] text-[96px] tracking-[-1.5px] whitespace-nowrap">16</p>
      </div>
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="<Button>">
        <Base18 />
      </div>
    </div>
  );
}

function Number3() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Number">
      <div className="flex flex-col items-center size-full">
        <div className="content-stretch flex flex-col items-center py-[16px] relative size-full">
          <div className="relative shrink-0 w-full" data-name="<Chart Numbers>">
            <div className="flex flex-row items-center size-full">
              <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
                <DataPoint4 />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function AdornIconStart() {
  return (
    <div className="content-stretch flex flex-col items-start pl-[4px] relative shrink-0 w-[20px]" data-name="AdornIcon Start">
      <div className="h-[14px] relative shrink-0 w-[18px]" data-name="FA Icon">
        <div className="absolute inset-[0_15%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.6 14">
            <path d={svgPaths.p1c70700} fill="var(--fill-0, #B34814)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Typography1() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center min-h-[24px] px-[6px] relative shrink-0" data-name="Typography">
      <p className="font-['Roboto:Regular',sans-serif] font-normal leading-[18px] relative shrink-0 text-[#b34814] text-[13px] tracking-[0.16px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        5 outstanding questions are high priority
      </p>
    </div>
  );
}

function Chip() {
  return (
    <div className="relative shrink-0 w-full" data-name="Chip">
      <div className="content-stretch flex flex-col items-start px-[16px] relative w-full">
        <div className="bg-[rgba(255,136,24,0.1)] content-stretch flex items-center max-h-[24px] min-h-[24px] overflow-clip px-[4px] py-[3px] relative rounded-[100px] shrink-0" data-name="<Chip>">
          <AdornIconStart />
          <Typography1 />
        </div>
      </div>
    </div>
  );
}

function WidgetQAProgress() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[8px] h-[276px] items-start min-w-[324px] overflow-clip pb-[16px] relative rounded-[8px] shadow-[0px_0px_8px_2px_rgba(219,218,215,0.25)] shrink-0 w-[324px]" data-name="<Widget Q&A Progress>">
      <div className="content-stretch flex gap-[8px] h-[62px] items-center p-[16px] relative shrink-0" data-name="<Widget Header>">
        <TitleAndInfoIcon6 />
        <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="<Button>">
          <Base17 />
        </div>
      </div>
      <Number3 />
      <Chip />
    </div>
  );
}

function TitleAndInfoIcon7() {
  return (
    <div className="content-stretch flex gap-[8px] h-[32px] items-center relative shrink-0" data-name="title and info icon">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>/Widget Name">
        <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[1.57] not-italic relative shrink-0 text-[#323232] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Documents by Language
        </p>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0 size-[16px]" data-name="<Icon Container>">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[0_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p30afdb00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon17() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base19() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Fileroom A
      </p>
      <MaskedIcon17 />
    </div>
  );
}

function WidgetHeaderVerticalAutoLayout() {
  return (
    <div className="relative shrink-0 w-full" data-name="<Widget Header> - vertical auto layout">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center p-[16px] relative w-full">
          <TitleAndInfoIcon7 />
          <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="<Button>">
            <Base19 />
          </div>
        </div>
      </div>
    </div>
  );
}

function Label14() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        English
      </p>
    </div>
  );
}

function Bar14() {
  return (
    <div className="bg-[#b34814] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="size-full" />
    </div>
  );
}

function ChartBar14() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 06>">
      <Label14 />
      <Bar14 />
    </div>
  );
}

function Label15() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        French
      </p>
    </div>
  );
}

function Bar15() {
  return (
    <div className="flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[50px] relative size-full">
        <div className="bg-[#b34814] flex-[1_0_0] min-h-px min-w-px w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function ChartBar15() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 05>">
      <Label15 />
      <Bar15 />
    </div>
  );
}

function Label16() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Spanish
      </p>
    </div>
  );
}

function Bar16() {
  return (
    <div className="flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="absolute bg-[#b34814] bottom-0 left-0 right-1/2 top-0" data-name="Series 1" />
    </div>
  );
}

function ChartBar16() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 04>">
      <Label16 />
      <Bar16 />
    </div>
  );
}

function Label17() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Portuguese
      </p>
    </div>
  );
}

function Bar17() {
  return (
    <div className="flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[192px] relative size-full">
        <div className="h-[24px] shrink-0 w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function ChartBar17() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center relative shrink-0 w-full" data-name="<Chart Bar 03>">
      <Label17 />
      <Bar17 />
    </div>
  );
}

function Label18() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Italian
      </p>
    </div>
  );
}

function Bar18() {
  return (
    <div className="flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[192px] relative size-full">
        <div className="h-[24px] shrink-0 w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function ChartBar18() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center relative shrink-0 w-full" data-name="<Chart Bar 02>">
      <Label18 />
      <Bar18 />
    </div>
  );
}

function Label19() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        German
      </p>
    </div>
  );
}

function Bar19() {
  return (
    <div className="flex-[1_0_0] h-[24px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[192px] relative size-full">
        <div className="h-[24px] shrink-0 w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function BarChart2() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Bar Chart">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[12px] items-start pl-[32px] pr-[16px] relative size-full">
          <ChartBar14 />
          <ChartBar15 />
          <ChartBar16 />
          <ChartBar17 />
          <ChartBar18 />
          <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="<Chart Bar 01>">
            <Label19 />
            <Bar19 />
          </div>
        </div>
      </div>
    </div>
  );
}

function WidgetDocumentsByLanguage() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[8px] h-[276px] items-start min-w-[324px] overflow-clip pb-[16px] relative rounded-[8px] shadow-[0px_0px_8px_2px_rgba(219,218,215,0.25)] shrink-0 w-[324px]" data-name="<Widget Documents by Language>">
      <WidgetHeaderVerticalAutoLayout />
      <BarChart2 />
    </div>
  );
}

function TitleAndInfoIcon8() {
  return (
    <div className="content-stretch flex gap-[8px] h-[32px] items-center relative shrink-0" data-name="title and info icon">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>/Widget Name">
        <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[1.57] not-italic relative shrink-0 text-[#323232] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Users by Language
        </p>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0 size-[16px]" data-name="<Icon Container>">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[0_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p30afdb00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon18() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base20() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        All Roles
      </p>
      <MaskedIcon18 />
    </div>
  );
}

function ChartPie1() {
  return (
    <div className="relative shrink-0 size-[190px]" data-name="<Chart Pie>">
      <div className="absolute inset-[-0.53%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 192 192">
          <g id="<Chart Pie>">
            <path d={svgPaths.p1f856800} fill="var(--fill-0, #53856D)" id="Ellipse 4" stroke="var(--stroke-0, white)" strokeWidth="2" />
            <path d={svgPaths.p21886f00} fill="var(--fill-0, #B34814)" id="Ellipse 5" stroke="var(--stroke-0, white)" strokeWidth="2" />
            <path d={svgPaths.pa6def00} fill="var(--fill-0, #1E4D36)" id="Ellipse 3" stroke="var(--stroke-0, white)" strokeWidth="2" />
            <path d={svgPaths.p1f38b800} fill="var(--fill-0, #FF8818)" id="Ellipse 2" stroke="var(--stroke-0, white)" strokeWidth="2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function WidgetContent1() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Widget Content">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-stretch flex items-center justify-center px-[8px] relative size-full">
          <ChartPie1 />
        </div>
      </div>
    </div>
  );
}

function WidgetInvitationStatus1() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[8px] h-[276px] items-start min-w-[324px] overflow-clip pb-[16px] relative rounded-[8px] shadow-[0px_0px_8px_2px_rgba(219,218,215,0.25)] shrink-0 w-[324px]" data-name="<Widget Invitation Status>">
      <div className="content-stretch flex gap-[8px] h-[62px] items-center p-[16px] relative shrink-0" data-name="<Widget Header>">
        <TitleAndInfoIcon8 />
        <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="<Button>">
          <Base20 />
        </div>
      </div>
      <WidgetContent1 />
    </div>
  );
}

function TitleAndInfoIcon9() {
  return (
    <div className="content-stretch flex gap-[8px] h-[32px] items-center relative shrink-0" data-name="title and info icon">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>/Widget Name">
        <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[1.57] not-italic relative shrink-0 text-[#323232] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Documents by Language
        </p>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0 size-[16px]" data-name="<Icon Container>">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[0_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p30afdb00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon19() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base21() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Fileroom A
      </p>
      <MaskedIcon19 />
    </div>
  );
}

function MaskedIcon20() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base22() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        View
      </p>
      <MaskedIcon20 />
    </div>
  );
}

function MaskedIcon21() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base23() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Published
      </p>
      <MaskedIcon21 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex items-start relative shrink-0">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
        <Base21 />
      </div>
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
        <Base22 />
      </div>
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
        <Base23 />
      </div>
    </div>
  );
}

function WidgetHeaderVerticalAutoLayout1() {
  return (
    <div className="relative shrink-0 w-full" data-name="<Widget Header> - vertical auto layout">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center p-[16px] relative w-full">
          <TitleAndInfoIcon9 />
          <Frame />
        </div>
      </div>
    </div>
  );
}

function Label20() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Microsoft
      </p>
    </div>
  );
}

function Bar20() {
  return (
    <div className="bg-[#fafaf7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="absolute bg-[#b34814] bottom-0 left-0 right-3/4 top-0" data-name="Series 1" />
    </div>
  );
}

function ChartBar19() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 01>">
      <Label20 />
      <Bar20 />
    </div>
  );
}

function Label21() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Amazon
      </p>
    </div>
  );
}

function Bar21() {
  return (
    <div className="bg-[#fafaf7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="absolute bg-[#b34814] bottom-0 left-0 right-1/2 top-0" data-name="Series 1" />
    </div>
  );
}

function ChartBar20() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 02>">
      <Label21 />
      <Bar21 />
    </div>
  );
}

function Label22() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>{`Procter & Gamble`}</p>
    </div>
  );
}

function Bar22() {
  return (
    <div className="bg-[#fafaf7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[59px] relative size-full">
        <div className="bg-[#b34814] flex-[1_0_0] min-h-px min-w-px w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function ChartBar21() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 03>">
      <Label22 />
      <Bar22 />
    </div>
  );
}

function Label23() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        DrDoctor
      </p>
    </div>
  );
}

function Bar23() {
  return (
    <div className="bg-[#fafaf7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="absolute bg-[#b34814] bottom-0 left-0 right-1/4 top-0" data-name="Series 1" />
    </div>
  );
}

function ChartBar22() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 04>">
      <Label23 />
      <Bar23 />
    </div>
  );
}

function Label24() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Meta (Facebook)
      </p>
    </div>
  );
}

function Bar24() {
  return (
    <div className="bg-[#fafaf7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[30px] relative size-full">
        <div className="bg-[#b34814] flex-[1_0_0] min-h-px min-w-px w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function ChartBar23() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 05>">
      <Label24 />
      <Bar24 />
    </div>
  );
}

function Label25() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-[80px]" data-name="Label">
      <p className="flex-[1_0_0] font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] min-h-px min-w-px overflow-hidden relative text-[#323232] text-[12px] text-ellipsis text-right tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        (6) Intellectual Property
      </p>
    </div>
  );
}

function Bar25() {
  return (
    <div className="bg-[#fafaf7] flex-[1_0_0] h-[8px] min-h-px min-w-px relative" data-name="Bar">
      <div className="content-stretch flex flex-col items-start pr-[20px] relative size-full">
        <div className="bg-[#b34814] flex-[1_0_0] min-h-px min-w-px w-full" data-name="Series 1" />
      </div>
    </div>
  );
}

function ChartBar24() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center overflow-clip relative shrink-0 w-full" data-name="<Chart Bar 06>">
      <Label25 />
      <Bar25 />
    </div>
  );
}

function BarChart3() {
  return (
    <div className="h-[160px] relative shrink-0 w-full" data-name="Bar Chart">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[12px] items-start pl-[32px] pr-[16px] relative size-full">
          <ChartBar19 />
          <ChartBar20 />
          <ChartBar21 />
          <ChartBar22 />
          <ChartBar23 />
          <ChartBar24 />
        </div>
      </div>
    </div>
  );
}

function WidgetPermissionsOverview() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[8px] items-start min-w-[324px] overflow-clip pb-[16px] relative rounded-[8px] shadow-[0px_0px_8px_2px_rgba(219,218,215,0.25)] shrink-0 w-[324px]" data-name="<Widget Permissions Overview>">
      <WidgetHeaderVerticalAutoLayout1 />
      <BarChart3 />
    </div>
  );
}

function TitleAndInfoIcon10() {
  return (
    <div className="content-stretch flex gap-[8px] h-[32px] items-center relative shrink-0" data-name="title and info icon">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>/Widget Name">
        <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[1.57] not-italic relative shrink-0 text-[#323232] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Project Volume
        </p>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0 size-[16px]" data-name="<Icon Container>">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[0_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p30afdb00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon22() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base24() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        All Locations
      </p>
      <MaskedIcon22 />
    </div>
  );
}

function DataPoint5() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-center min-h-px min-w-px relative" data-name="Data Point 1">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>">
        <p className="font-['AL_Sigla_Trial:Light',sans-serif] leading-[1.2] not-italic relative shrink-0 text-[#323232] text-[60px] tracking-[-0.5px] whitespace-nowrap">471</p>
      </div>
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>">
        <p className="font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] relative shrink-0 text-[#6a6a69] text-[12px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Documents
        </p>
      </div>
    </div>
  );
}

function MinWidth1() {
  return <div className="h-0 shrink-0 w-px" data-name="min-width" />;
}

function Divider1() {
  return (
    <div className="h-full relative shrink-0" data-name="Divider">
      <div className="flex flex-row justify-center size-full">
        <div className="content-stretch flex h-full items-start justify-center pb-[44px] pt-[28px] relative">
          <div className="content-stretch flex flex-col h-[24px] items-start relative shrink-0" data-name="<Divider> | Vertical">
            <MinWidth1 />
            <div className="flex flex-[1_0_0] items-center justify-center min-h-px min-w-px relative w-0" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "19" } as React.CSSProperties}>
              <div className="flex-none h-full rotate-90">
                <div className="h-full relative w-[220px]" data-name="Divider">
                  <div className="absolute inset-[-1px_0_0_0]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 1">
                      <line id="Divider" stroke="var(--stroke-0, #191919)" strokeOpacity="0.12" x2="24" y1="0.5" y2="0.5" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataPoint6() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-center min-h-px min-w-px relative" data-name="Data Point 2">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>">
        <p className="font-['AL_Sigla_Trial:Light',sans-serif] leading-[1.2] not-italic relative shrink-0 text-[#323232] text-[60px] tracking-[-0.5px] whitespace-nowrap">445</p>
      </div>
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>">
        <p className="font-['Roboto:Regular',sans-serif] font-normal leading-[1.66] relative shrink-0 text-[#6a6a69] text-[12px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Folders
        </p>
      </div>
    </div>
  );
}

function Number4() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-center justify-center min-h-px min-w-px relative w-full" data-name="Number">
      <div className="content-stretch flex gap-[8px] items-center relative shrink-0 w-full" data-name="<Chart Numbers>">
        <DataPoint5 />
        <div className="flex flex-row items-center self-stretch">
          <Divider1 />
        </div>
        <DataPoint6 />
      </div>
    </div>
  );
}

function WidgetProjectVolume() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[8px] h-[276px] items-start min-w-[324px] overflow-clip pb-[16px] relative rounded-[8px] shadow-[0px_0px_8px_2px_rgba(219,218,215,0.25)] shrink-0 w-[324px]" data-name="<Widget Project Volume>">
      <div className="content-stretch flex gap-[8px] h-[62px] items-center p-[16px] relative shrink-0" data-name="<Widget Header>">
        <TitleAndInfoIcon10 />
        <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="<Button>">
          <Base24 />
        </div>
      </div>
      <Number4 />
    </div>
  );
}

function TitleAndInfoIcon11() {
  return (
    <div className="content-stretch flex gap-[8px] h-[32px] items-center relative shrink-0" data-name="title and info icon">
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>/Widget Name">
        <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[1.57] not-italic relative shrink-0 text-[#323232] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          Document by Folder
        </p>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0 size-[16px]" data-name="<Icon Container>">
        <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
          <div className="absolute inset-[0_10%]" data-name="Primary">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p30afdb00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function MaskedIcon23() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Masked Icon">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[16px] left-1/2 top-1/2 w-[20px]" data-name="angle-down icon light">
        <div className="absolute inset-[34.38%_22.51%_28.13%_22.51%]" data-name="Primary">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9969 5.99687">
            <path d={svgPaths.p2c008800} fill="var(--fill-0, #4E4E4D)" id="Primary" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Base25() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['TT_Hoves_Pro_VF_Trial:Medium',sans-serif] font-medium leading-[24px] not-italic relative shrink-0 text-[#4e4e4d] text-[14px] tracking-[0.4px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Fileroom A
      </p>
      <MaskedIcon23 />
    </div>
  );
}

function DashboardWidgets() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Dashboard Widgets">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-start flex flex-wrap gap-[32px] items-start pt-[32px] px-[32px] relative size-full">
          <div className="bg-white content-stretch flex flex-col h-[276px] items-start min-w-[324px] overflow-clip relative rounded-[8px] shadow-[0px_0px_8px_2px_rgba(219,218,215,0.25)] shrink-0 w-[324px]" data-name="<Widget Documents Shortcuts>">
            <div className="h-[62px] relative shrink-0 w-full" data-name="<Widget Header>">
              <div className="flex flex-row items-center size-full">
                <div className="content-center flex flex-wrap gap-[8px] items-center p-[16px] relative size-full">
                  <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="<Typography>/Widget Name">
                    <p className="font-['Roboto:Medium',sans-serif] font-medium leading-[1.57] relative shrink-0 text-[#1f2227] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
                      Documents Shortcuts
                    </p>
                  </div>
                  <div className="content-stretch flex items-center justify-center relative shrink-0 size-[16px]" data-name="<Icon Container>">
                    <div className="h-[16px] relative shrink-0 w-[20px]" data-name="FA icon">
                      <div className="absolute inset-[0_10%]" data-name="Primary">
                        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
                          <path d={svgPaths.p30afdb00} fill="var(--fill-0, #4E4E4D)" id="Primary" />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <ShortcutForDocs />
          </div>
          <WidgetDocumentActions />
          <WidgetDocumentsPublished />
          <WidgetInvitationStatus />
          <WidgetEmptyFolders />
          <WidgetDocumentsPublished1 />
          <WidgetPlaceholders />
          <WidgetQAProgress />
          <WidgetDocumentsByLanguage />
          <WidgetInvitationStatus1 />
          <WidgetPermissionsOverview />
          <WidgetProjectVolume />
          <div className="content-stretch flex gap-[8px] h-[62px] items-start p-[16px] relative shrink-0" data-name="<Widget Header>">
            <TitleAndInfoIcon11 />
            <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[8px] py-[4px] relative rounded-[8px] shrink-0" data-name="<Button>">
              <Base25 />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

type TooltipProps = {
  text?: string;
};

function Tooltip({ text = "" }: TooltipProps) {
  return (
    null
  );
}
type TooltipLeftProps = {
  className?: string;
  text?: string;
};

function TooltipLeft({ className, text = "Shows an up-to-date view of your projects new, inbox and action required tabs" }: TooltipLeftProps) {
  return (
    <div className={className || "absolute content-stretch flex items-center left-[172px] top-[425px] w-[447px]"} data-name="<Tooltip>/Left">
      
    </div>
  );
}

function PageContent() {
  return (
    <div className="content-stretch flex flex-col h-[976px] items-start overflow-clip relative shrink-0 w-[1456px]" data-name="Page Content" style={{ backgroundImage: "linear-gradient(178.591deg, rgb(250, 250, 247) 1.7353%, rgb(247, 246, 242) 50.432%)" }}>
      <PageHeader />
      <DashboardWidgets />
      <TooltipLeft />
    </div>
  );
}

function MainContainer() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-center min-h-px min-w-px relative w-full" data-name="Main Container">
      <div className="bg-[#fafaf7] content-stretch flex flex-col h-full items-start relative shrink-0 w-[80px]" data-name="<LeftNav>">
        <div aria-hidden="true" className="absolute border-[rgba(25,25,25,0.12)] border-r border-solid inset-0 pointer-events-none" />
        <div className="content-stretch flex flex-col gap-[4px] h-[68px] items-center justify-center relative shrink-0 w-full" data-name="_<LeftNavItem>">
          <IconContainer />
          <p className="font-['Roboto:Regular',sans-serif] font-normal leading-none min-w-full relative shrink-0 text-[#1f2227] text-[10px] text-center tracking-[0.4px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
            Dashboard
          </p>
        </div>
        <div className="content-stretch flex flex-col gap-[4px] h-[68px] items-center justify-center relative shrink-0 w-full" data-name="_<LeftNavItem>">
          <IconContainer1 />
          <p className="font-['Roboto:Regular',sans-serif] font-normal leading-none min-w-full relative shrink-0 text-[#1f2227] text-[10px] text-center tracking-[0.4px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
            Documents
          </p>
        </div>
        <div className="content-stretch flex flex-col gap-[4px] h-[68px] items-center justify-center relative shrink-0 w-full" data-name="_<LeftNavItem>">
          <IconContainer2 />
          <p className="font-['Roboto:Regular',sans-serif] font-normal leading-none min-w-full relative shrink-0 text-[#1f2227] text-[10px] text-center tracking-[0.4px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
            Search
          </p>
        </div>
        <div className="content-stretch flex flex-col gap-[4px] h-[68px] items-center justify-center relative shrink-0 w-full" data-name="_<LeftNavItem>">
          <IconContainer3 />
          <p className="font-['Roboto:Regular',sans-serif] font-normal leading-none min-w-full relative shrink-0 text-[#1f2227] text-[10px] text-center tracking-[0.4px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
            Trackers
          </p>
        </div>
        <div className="content-stretch flex flex-col gap-[4px] h-[68px] items-center justify-center relative shrink-0 w-full" data-name="_<LeftNavItem>">
          <IconContainer4 />
          <p className="font-['Roboto:Regular',sans-serif] font-normal leading-none min-w-full relative shrink-0 text-[#1f2227] text-[10px] text-center tracking-[0.4px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>{`Q&A`}</p>
        </div>
        <div className="content-stretch flex flex-col gap-[4px] h-[68px] items-center justify-center relative shrink-0 w-full" data-name="_<LeftNavItem>">
          <IconContainer5 />
          <p className="font-['Roboto:Regular',sans-serif] font-normal leading-none min-w-full relative shrink-0 text-[#1f2227] text-[10px] text-center tracking-[0.4px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
            Users
          </p>
        </div>
        <div className="content-stretch flex flex-col gap-[4px] h-[68px] items-center justify-center relative shrink-0 w-full" data-name="_<LeftNavItem>">
          <IconContainer6 />
          <p className="font-['Roboto:Regular',sans-serif] font-normal leading-none min-w-full relative shrink-0 text-[#1f2227] text-[10px] text-center tracking-[0.4px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
            Permissions
          </p>
        </div>
        <div className="content-stretch flex flex-col gap-[4px] h-[68px] items-center justify-center relative shrink-0 w-full" data-name="_<LeftNavItem>">
          <IconContainer7 />
          <p className="font-['Roboto:Regular',sans-serif] font-normal leading-none min-w-full relative shrink-0 text-[#1f2227] text-[10px] text-center tracking-[0.4px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
            Redaction
          </p>
        </div>
        <div className="content-stretch flex flex-col gap-[4px] h-[68px] items-center justify-center relative shrink-0 w-full" data-name="_<LeftNavItem>">
          <IconContainer8 />
          <p className="font-['Roboto:Regular',sans-serif] font-normal leading-none min-w-full relative shrink-0 text-[#1f2227] text-[10px] text-center tracking-[0.4px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
            Archives
          </p>
        </div>
        <div className="content-stretch flex flex-col gap-[4px] h-[68px] items-center justify-center relative shrink-0 w-full" data-name="_<LeftNavItem>">
          <IconContainer9 />
          <p className="font-['Roboto:Regular',sans-serif] font-normal leading-none min-w-full relative shrink-0 text-[#1f2227] text-[10px] text-center tracking-[0.4px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
            Analytics
          </p>
        </div>
        <div className="content-stretch flex flex-col gap-[4px] h-[68px] items-center justify-center relative shrink-0 w-full" data-name="_<LeftNavItem>">
          <IconContainer10 />
          <p className="font-['Roboto:Regular',sans-serif] font-normal leading-none min-w-full relative shrink-0 text-[#1f2227] text-[10px] text-center tracking-[0.4px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
            Settings
          </p>
        </div>
      </div>
      <PageContent />
    </div>
  );
}

export default function DiligenceDashboardHaloDesignSprint() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start relative size-full" data-name="Diligence Dashboard - Halo Design Sprint">
      <TopNavBar />
      <MainContainer />
    </div>
  );
}